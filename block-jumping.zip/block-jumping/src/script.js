document.getElementById("restartBtn").onclick = () => {
  // Reset game state
  dead = false;
  score = 0;
  speed = 0.14;
  yVel = 0;
  grounded = true;

  dino.position.y = 0.6;
  resetObstacle();

  document.getElementById("score").innerText = 0;
  document.getElementById("over").style.display = "none";
};
